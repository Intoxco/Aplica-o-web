<?php
abstract class Usuario{
    protected $login;
    protected $senha;
    protected $idUsuario;

    public function getLogin (){
        return $this->login;
    }  
    public function setLogin($login){
        $this->login  = $login;
    }
    public function getSenha(){
        return $this->senha;
    }
    public function setSenha($senha){
        $this->senha = $senha;
    }
    public function getIdUsuario(){
        return $this->idUsuario;
    }

    public static function autenticar($login, $senha) {
        try {
            $bd = Conexao::get();

            // Prepare the SQL statement to fetch the user
            $query = $bd->prepare("SELECT * FROM usuario WHERE login = :login");
            $query->bindParam(':login', $login);
            $query->execute();

            // Fetch the user data
            $usuario = $query->fetch(PDO::FETCH_ASSOC);

            // Check if the user exists
            if (!$usuario) {
                return ['erro' => 'Usuário não encontrado.'];
            }

            
            if ($senha === $usuario['senha']) {
                // Determine the user's role
                $role = self::pegarFuncao($usuario['idUsuario']);
                $usuario['funcao'] = $role; 
                return $usuario;
            } else {
                return ['erro' => 'Senha incorreta.'];
            }

        } catch (PDOException $e) {
            throw new Exception("Erro ao autenticar: " . $e->getMessage());
        }
    }

    private static function pegarFuncao($idUsuario) {
        try {
            $bd = Conexao::get();

            $query = $bd->prepare("SELECT * FROM admin WHERE idUsuario = :idUsuario");
            $query->bindParam(':idUsuario', $idUsuario);
            $query->execute();
            if ($query->fetch(PDO::FETCH_ASSOC)) {
                return 'admin';
            }

            
            $query = $bd->prepare("SELECT * FROM professor WHERE idUsuario = :idUsuario");
            $query->bindParam(':idUsuario', $idUsuario);
            $query->execute();
            if ($query->fetch(PDO::FETCH_ASSOC)) {
                return 'professor';
            }

            
            $query = $bd->prepare("SELECT * FROM aluno WHERE idUsuario = :idUsuario");
            $query->bindParam(':idUsuario', $idUsuario);
            $query->execute();
            if ($query->fetch(PDO::FETCH_ASSOC)) {
                return 'aluno';
            }

            return 'unknown'; 
        } catch (PDOException $e) {
            throw new Exception("Erro ao verificar função do usuário: " . $e->getMessage());
        }
    }
}




