<?php
session_start();
require('view-login.php');
require('../entities/Usuario.php');
require('../database/conexao.php');


$error = $_SESSION['error'] ?? false;


$login = trim($_POST['usuario'] ?? ''); 
$senha = trim($_POST['senha'] ?? '');    


if (!isset($_SESSION['logado']) || !$_SESSION['logado']) {
    
    if (!empty($login) && !empty($senha)) {
        
        $dadosUsuario = Usuario::autenticar($login, $senha);

        
        if (isset($dadosUsuario['erro'])) {
            $_SESSION['error'] = $dadosUsuario['erro'];
        } else {
            
            $_SESSION['logado'] = true;
            $_SESSION['usuario'] = $dadosUsuario['login'];
            $_SESSION['idUsuario'] = $dadosUsuario['idUsuario']; 

           
            session_regenerate_id(true);

            
            switch ($dadosUsuario['funcao']) {
                case 'professor':
                    header('Location: ../professor/index-professor.php');
                    break;
                case 'aluno':
                    header('Location: ../aluno/view-aluno.php');
                    break;
                    case 'admin':
                        header('Location: ../admin/controller-cadastro-aluno.php');
                        exit();
                    default:
                        $_SESSION['error'] = 'Função do usuário desconhecida.';
                        header('Location: view-login.php');
                        exit();
                }
            }
        } else {
            $_SESSION['error'] = 'Preencha todos os campos.';
        }
    }
    
    
    if ($error) {
        unset($_SESSION['error']);
    }
        