<?php

header("Location: login/view-login.php");