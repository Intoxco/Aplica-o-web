<?php 
require('../database/Conexao.php');

$bd = Conexao::get();
session_start();

if (!isset($_SESSION['logado'])) {
    header('Location: ../login/controller-login.php');
    exit();
}

if ($_SESSION[$_SESSION["usuario"]]["funcao"] == 'aluno') {
    $mensagem = "Você não tem permissão para acessar esta página.";
    $botao = "Ir para minha área";
    $urlBotao = "../aluno/view-aluno.php";
    $acaoBotao = "deslogar";
} else if($_SESSION[$_SESSION["usuario"]]["funcao"] == "professor"){
    $mensagem = "Você não tem permissão para acessar esta página";
    $botao = "Ir para minha área";
    $urlBotao = "../professor/index-professor.php";
    $acaoBotao = "deslogar";
}else{
    $erro = $_SESSION['erro'] ?? '';
    $sucesso = $_SESSION['sucesso'] ?? '';
    
    unset($_SESSION['erro']);
    unset($_SESSION['sucesso']);
}


if (isset($_POST["envio"]) && $_POST["envio"] == "true") {
    
   
    $login = trim($_POST["alunoLogin"]);
    $senha = trim($_POST["alunoSenha"]);
    $nome = trim($_POST["alunoNome"]);
    $idade = trim($_POST["alunoIdade"]);
    $nomeResponsavel = trim($_POST["alunoResponsavel"]);
    $idTurma = $_POST["alunoTurma"];

    
    $query = $bd->prepare("SELECT * FROM usuario WHERE login = :login");
    $query->bindParam(':login', $login);
    $query->execute();

    if ($query->rowCount() > 0) {
        $_SESSION['erro'] = "O login inserido já está em uso!";
        header("Location: controller-cadastro-aluno.php");
        exit();
    } else {
       
        $query = $bd->prepare("INSERT INTO usuario (login, senha, funcao) VALUES (:login, :senha, 'aluno')");
        $query->bindParam(':login', $login);
        $query->bindParam(':senha', password_hash($senha, PASSWORD_DEFAULT));
        $query->execute();

        
        $idUsuario = $bd->lastInsertId();

        
        $query = $bd->prepare("INSERT INTO aluno (nome, idade, nomeResponsavel, idTurma, idUsuario) VALUES (:nome, :idade, :nomeResponsavel, :idTurma, :idUsuario)");
        
        $query->bindParam(':nome', $nome);
        $query->bindParam(':idade', $idade);
        $query->bindParam(':nomeResponsavel', $nomeResponsavel);
        $query->bindParam(':idTurma', $idTurma);
        $query->bindParam(':idUsuario', $idUsuario);

        if ($query->execute()) {
            $_SESSION['sucesso'] = 'Aluno cadastrado com sucesso!';
        } else {
            $_SESSION['erro'] = 'Erro ao cadastrar aluno.';
        }
    }

    
    header("Location: controller-cadastro-aluno.php");
    exit();
}

require "view-cadastro-aluno.php";
?>
