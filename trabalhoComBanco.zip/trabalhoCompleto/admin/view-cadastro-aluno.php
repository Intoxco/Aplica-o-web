<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Trabalho PHP</title>
    <link rel="stylesheet" href="../css/style_professor.css">
    <link rel="icon" href="../assets/logo.png" type="image/png">
    <link rel="stylesheet" href="../css/navbar.css">
    <style>
        body{
            display:flex;
            flex-direction:column;
        }
    </style>
</head>
<body>
    <?php include '../includes/navbar.php';?>
    <?php if (isset($mensagem)): ?>
        <div class="access-denied">
            <p><?php echo $mensagem; ?></p>
            <button onclick="window.location.href='<?php echo $urlBotao; ?>'"><?php echo $botao; ?></button>
            <button onclick="window.location.href='../login/logout.php'">Logout</button>
        </div>
    <?php elseif (isset($erro) || isset($sucesso)): ?>
        <?php if ($erro): ?>
            <p class="error"><?php echo $erro; ?></p>
        <?php endif; ?>
        <?php if ($sucesso): ?>
            <p style="color:green;"class="success"><?php echo $sucesso; ?></p>
        <?php endif; ?>
        <form method="POST" action="controller-cadastro-aluno.php">
    <fieldset>
        <legend>CADASTRAR ALUNO</legend>
        <p>
            <label for="alunoLogin">LOGIN</label>
            <input name="alunoLogin" type="text" required>
        </p>
        <p>
            <label for="alunoSenha">SENHA</label>
            <input name="alunoSenha" type="password" required>
        </p>
        <p>
            <label for="alunoNome">NOME</label>
            <input name="alunoNome" type="text" required>
        </p>
        <p>
            <label for="alunoIdade">IDADE</label>
            <input name="alunoIdade" type="number" min="6" max="30" required>
        </p>
        <p>
            <label for="alunoResponsavel">NOME RESPONSÁVEL</label>
            <input name="alunoResponsavel" type="text" required>
        </p>
        <p>
            <label for="alunoTurma">TURMA</label>
            <select name="alunoTurma" required>
                <option selected disabled>Selecione a Turma</option>
                <?php
                    $bd = Conexao::get();
                    $query = $bd->query("SELECT * FROM turma");
                    while ($turma = $query->fetch(PDO::FETCH_ASSOC)) {
                        echo "<option value='{$turma['idTurma']}'>{$turma['ano']} - {$turma['periodo']}</option>";
                    }
                ?>
            </select>
        </p>
    </fieldset>
    <button type="submit" name="envio" value="true">Cadastrar</button>
</form>
    <?php endif; ?>
</body>
</html>