
function processarLogin() {
    const userField = document.getElementById('user');
    const passwordField = document.getElementById('password');

    const user = userField.value;
    const password = passwordField.value;

    const storedData = JSON.parse(localStorage.getItem(user));
    if (storedData && password === storedData.password) {
        const url = 'index.html?user=' + encodeURIComponent(user);
        location.assign(url);
    } else {
        alert('Usuário ou senha incorretos.');
    }
}



document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('loginForm');

    form.addEventListener('submit', (e) => {
        e.preventDefault();
        processarLogin();
    });

    const loginButton = document.getElementById('loginButton');
    loginButton.addEventListener('click', () => {
        form.dispatchEvent(new Event('submit'));
    });
});
