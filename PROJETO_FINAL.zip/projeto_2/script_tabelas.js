
function addLinha() {
    const data = new Date();
    var tbody = document.getElementById('corpoTabela');
    
    var novaLinha = tbody.insertRow();
    
    var idValor = Math.round(Math.random() * (10000 - 10) + 10);
    var nomeValor = document.getElementById('nomeItem').value;
    const dataAtual = `${data.getDay()}/${data.getMonth()}/${data.getFullYear()}`;
    var acoesValor = "";
    
    var id = novaLinha.insertCell(0);
    var nome = novaLinha.insertCell(1);
    var criado = novaLinha.insertCell(2);
    var acao = novaLinha.insertCell(3);
    
    id.textContent = idValor;
    nome.textContent = nomeValor;
    criado.textContent = dataAtual;
    
    var btnEditar = document.createElement("button");
    btnEditar.textContent = "Editar";
    btnEditar.addEventListener('click', function() {
        nome.setAttribute("contenteditable", true);
        nome.focus();
        nome.addEventListener("keypress", function(event) {
            if (event.key === "Enter") {
                nome.setAttribute("contenteditable", false);
                nomeValor = nome.textContent;
                atualizarLocalStorage();
            }
        });
    });
    
    var btnExcluir = document.createElement("button");
    btnExcluir.textContent = "Excluir";
    btnExcluir.addEventListener('click', function() {
        tbody.removeChild(novaLinha);
        atualizarLocalStorage();
    });
    
    acao.appendChild(btnEditar);
    acao.appendChild(btnExcluir);
    
    const urlParams = new URLSearchParams(window.location.search);
    const username = urlParams.get('user');
    
    if (username) {
        const userKey = 'lista_' + username;
        const listaUsuario = JSON.parse(localStorage.getItem(userKey)) || [];
        const novaLinhaUsuario = { id: idValor, nome: nomeValor, criado: dataAtual };
        listaUsuario.push(novaLinhaUsuario);
        localStorage.setItem(userKey, JSON.stringify(listaUsuario));
    }
    
    document.getElementById('nomeItem').value = '';
    document.getElementById('nomeItem').focus();
    
}

function carregarLinhas() {
    const urlParams = new URLSearchParams(window.location.search);
    const username = urlParams.get('user');
    
    if (username) {
        const userKey = 'lista_' + username;
        const listaUsuario = JSON.parse(localStorage.getItem(userKey)) || [];
        
        const tbody = document.getElementById('corpoTabela');
        
        listaUsuario.forEach(item => {
            const novaLinha = tbody.insertRow();
            var id = novaLinha.insertCell(0);
            var nome = novaLinha.insertCell(1);
            var criado = novaLinha.insertCell(2);
            var acao = novaLinha.insertCell(3);
            
            id.textContent = item.id;
            nome.textContent = item.nome;
            criado.textContent = item.criado;
            
            var btnEditar = document.createElement("button");
            btnEditar.textContent = "Editar";
            btnEditar.addEventListener('click', function() {
                nome.setAttribute("contenteditable", true);
                nome.focus();
                nome.addEventListener("keypress", function(event) {
                    if (event.key === "Enter") {
                        nome.setAttribute("contenteditable", false);
                        item.nome = nome.textContent;
                        atualizarLocalStorage();
                    }
                });
            });
            
            var btnExcluir = document.createElement("button");
            btnExcluir.textContent = "Excluir";
            btnExcluir.addEventListener('click', function() {
                tbody.removeChild(novaLinha);
                listaUsuario.splice(listaUsuario.indexOf(item), 1);
                atualizarLocalStorage();
            });
            
            acao.appendChild(btnEditar);
            acao.appendChild(btnExcluir);
        });
        const currentUserElement = document.getElementById('currentUser');
        if (currentUserElement) {
            currentUserElement.textContent = " "+ username + "!";
        }
    }
}

function atualizarLocalStorage() {
    const urlParams = new URLSearchParams(window.location.search);
    const username = urlParams.get('user');
    const userKey = 'lista_' + username;
    const tbody = document.getElementById('corpoTabela');
    const listaUsuario = [];
    
    for (let i = 0; i < tbody.rows.length; i++) {
        const id = tbody.rows[i].cells[0].textContent;
        const nome = tbody.rows[i].cells[1].textContent;
        const criado = tbody.rows[i].cells[2].textContent;
        listaUsuario.push({ id, nome, criado });
    }

    localStorage.setItem(userKey, JSON.stringify(listaUsuario));
}


document.addEventListener('DOMContentLoaded', () => {
    carregarLinhas();
    document.getElementById("form").addEventListener('submit', (e) => {
        e.preventDefault();
        addLinha();
    });
});
