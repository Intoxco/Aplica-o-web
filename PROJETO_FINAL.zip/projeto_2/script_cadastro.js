
function processarCadastro() {
    const usernameField = document.getElementById('username');
    const passwordField = document.getElementById('password');

    const username = usernameField.value;
    const password = passwordField.value;

    
    if (username.trim() === '' || password.trim() === '') {
        alert('Por favor, preencha todos os campos.');
        return;
    }
    
    if (localStorage.getItem(username)) {
        alert('Este usuário já está cadastrado.');
        return;
    }

    
    localStorage.setItem(username, JSON.stringify({ password }));

    
    const url = 'index.html?user=' + encodeURIComponent(username);
    location.assign(url);

    
    usernameField.value = '';
    passwordField.value = '';

    alert('Cadastro realizado com sucesso!');
}

document.addEventListener('DOMContentLoaded', () => {
    const registerForm = document.getElementById('registerForm');

    registerForm.addEventListener('submit', (e) => {
        e.preventDefault();
        processarCadastro();
    });
});
